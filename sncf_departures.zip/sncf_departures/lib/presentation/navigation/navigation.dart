class Navigation {
  static final home = "/home";
  static final setPrefs = "/setPrefs";
  static final splash = "/";
}
