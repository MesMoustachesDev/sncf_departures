import 'package:flutter/foundation.dart';

class SncfSchedulesKeys {
  // Home Screens
  static final homeScreen = const Key('__homeScreen__');
  static final setPrefsScreen = const Key('__setPrefsScreen__');
  static final splashScreen = const Key('__splashScreen__');
}
